<?php 
session_start();
if (!isset($_SESSION['login'])) {
	header("location:login.php?login+dulu");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <h1>Tambah Post</h1>
    <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        <label for="">Foto</label>
        <input type="file" name="foto" id="" required><br>

        <label for="">Caption</label>
        <input type="text" name="caption" id="" autocomplete="off"><br>

        <label for="">Lokasi</label>
        <input type="text" name="lokasi" id="" autocomplete="off"><br>

        <input type="submit" value="Simpan" name="simpan">
    </form>
</body>
</html>