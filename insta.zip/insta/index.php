<?php
session_start();
if (!isset($_SESSION['login'])) {
	header("location:login.php?login+dulu");
}

include "koneksi.php";
$sql = "SELECT * FROM post ORDER BY no DESC";
$query = mysqli_query($koneksi,$sql);
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" href="assets/logo.png" class="rounded" type="imagle/x-icon">
	<title>MemeGram</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style type="text/css">
    	.zoom {
    		overflow: hidden;
    		border-radius: 15px;
    	}
    	.zoom img{
    		transition: all 0.3s;
    	}
    	.zoom:hover img{
    		transform: scale(1.25);
    	}
    </style>
</head>
<body>

<div>
	<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top shadow-sm bg-body rounded">
		<div class="container-fluid">
			<div class="d-flex flex-row justify-content-between col-10 ml-4">
				<div class="nav" style="align-items: center;">
					<a class="nav navbar-nav navbar-center">
				      <img src="assets/logo.png" alt="" width="25" height="25" class="mr-1 rounded">
				      MEMEGRAM
				    </a>
				</div>
			    <div>
					<form class="d-flex">
				        <input class="form-control me-2 text-center" type="search" placeholder="Search" aria-label="Search">
			      	</form>
			    </div>
			    <div>
			    	<ul class="list-inline m-0">
			    		<li class="list-inline-item">
			    			<button type="button" class="btn fa" data-bs-toggle="modal" data-bs-target="#exampleModal" style="margin-right: -25px;">
			    				<svg xmlns="http://www.w3.org/2000/svg" height="1.5em" viewBox="0 0 448 512"><path d="M64 32C28.7 32 0 60.7 0 96V416c0 35.3 28.7 64 64 64H384c35.3 0 64-28.7 64-64V96c0-35.3-28.7-64-64-64H64zM200 344V280H136c-13.3 0-24-10.7-24-24s10.7-24 24-24h64V168c0-13.3 10.7-24 24-24s24 10.7 24 24v64h64c13.3 0 24 10.7 24 24s-10.7 24-24 24H248v64c0 13.3-10.7 24-24 24s-24-10.7-24-24z"/></svg>
								</button>
			    		</li>
			    		<li class="list-inline-item">
			    			<a href="logout.php" class="btn fa"><svg xmlns="http://www.w3.org/2000/svg" height="1.5em" viewBox="0 0 512 512"><style>svg{fill:#ffffff}</style><path d="M377.9 105.9L500.7 228.7c7.2 7.2 11.3 17.1 11.3 27.3s-4.1 20.1-11.3 27.3L377.9 406.1c-6.4 6.4-15 9.9-24 9.9c-18.7 0-33.9-15.2-33.9-33.9l0-62.1-128 0c-17.7 0-32-14.3-32-32l0-64c0-17.7 14.3-32 32-32l128 0 0-62.1c0-18.7 15.2-33.9 33.9-33.9c9 0 17.6 3.6 24 9.9zM160 96L96 96c-17.7 0-32 14.3-32 32l0 256c0 17.7 14.3 32 32 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-53 0-96-43-96-96L0 128C0 75 43 32 96 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32z"/></svg></a>
			    		</li>
			    	</ul>
			    </div>
			</div>
		</div>
	</nav>
</div>

<br>
<br>
<?php while ($post = mysqli_fetch_assoc($query)) { ?>
<div class="container d-flex align-items-center flex-column ml-0">
	<br>
	<div class="card justify-content-center shadow p-3 bg-body rounded" style="width: 31rem;">
		<div class="d-flex mt-1">
			<ul class="list-inline mr-1">
				<li class="list-inline-item ml-1"><svg xmlns="http://www.w3.org/2000/svg" height="3em" viewBox="0 0 512 512"><style>svg{fill:#000000}</style><path d="M399 384.2C376.9 345.8 335.4 320 288 320H224c-47.4 0-88.9 25.8-111 64.2c35.2 39.2 86.2 63.8 143 63.8s107.8-24.7 143-63.8zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm256 16a72 72 0 1 0 0-144 72 72 0 1 0 0 144z"/></svg></li>
			</ul>
			<ul class="list-inline ml-2">
				<li class="list-inline"><h4><?= $_SESSION['login']?></h4></li>
				<li class="list-inline" style="margin-top: -12px;"><h6 class="card-title">berada di <?= $post['lokasi'] ?></h6></li>
			</ul>
		</div> 
		<div class="zoom">
			<img class="card-img-top zoom" src="images/<?= $post['foto'] ?>" alt="Card image cap" style="border-radius: 15px">
		</div>
	  <div class="d-flex " style="position: absolute;top:2%;left: 85%;">
		  <a href="edit.php?no=<?= $post['no'] ?>" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $post['no'] ?>"><i class="fa fa-pencil" style="font-size:24px; position: absolute;right:65%;"></i></a>
		  <a href="hapus.php?no=<?= $post['no'] ?>" class="btn"><i class="fa fa-trash" style="font-size:24px"></i></a>
		</div>
	  <div class="card-body">
	    
	    <p><?= $post['caption'] ?></p>
	  </div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal<?= $post['no'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit</h5>
        <button type="button" class="btn btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        	<input type="hidden" name="no" value="<?= $post['no'] ?>">
    			<input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">

	        <label for="" class="form-label">Foto</label>
	        <input class="form-control" type="file" name="foto" id="" value="<?= $post['foto'] ?>" ><br>
        	<img src="images/<?= $post['foto'] ?>" width="200" alt="" ><br><br>

	        <label for="" class="form-label">Caption</label>
	        <input type="text" name="caption" id="" value="<?= $post['caption'] ?>" autocomplete="off" class="form-control"><br>

	        <label for="" class="form-label">Lokasi</label>
	        <input type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" autocomplete="off" class="form-control"><br>
	        
	        <div class="modal-footer">
		        <input type="submit" value="Simpan" name="ubah" class="btn btn-outline-dark">
		    </div>
	    </form>
      </div>
    </div>
  </div>
</div>

<br>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah</h5>
        <button type="button" class="btn btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
	        <label for="" class="form-label">Foto</label>
	        <input type="file" name="foto" id="" required class="form-control"><br>

	        <label for="" class="form-label">Caption</label>
	        <textarea type="text" name="caption" id="" autocomplete="off" class="form-control"></textarea>
	        <!-- <input type="text" name="caption" id="" autocomplete="off" class="form-control"><br> -->

	        <label for="" class="form-label">Lokasi</label>
	        <input type="text" name="lokasi" id="" autocomplete="off" class="form-control"><br>
	        
	        <div class="modal-footer">
	        	<input type="submit" value="Simpan" name="simpan" class="btn btn-outline-dark">
		       </div>
		    </div>
	    </form>
      </div>
    </div>
  </div>
</div>

<?php } ?>
</body>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</html>

